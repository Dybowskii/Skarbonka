Projekt Wirtualnej Skarbonki 

Backend:Kamila Babicka, Dominik Dybowski 

Frontend: Joanna Bulwan, Szymon Świerzbin
