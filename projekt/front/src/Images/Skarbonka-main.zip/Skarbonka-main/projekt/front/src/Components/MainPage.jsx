import React from "react";
function MainPage()
{
    return<div>
        <div className="container">
                <div className="content">
                <h1>System Skarbonek</h1>
                <h2>Zaloguj się lub stwórz konto by poznać szczegóły.</h2>
                </div>
            </div>
    </div>
}
export default MainPage;