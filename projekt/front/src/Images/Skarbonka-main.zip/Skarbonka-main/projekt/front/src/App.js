import "./App.css";
import React from "react";
import { BrowserRouter } from "react-router-dom"
import Nawigacja from "./Components/Nawigacja";

function App() {
  return (
    <BrowserRouter><Nawigacja /></BrowserRouter>
  );
}

export default App;
