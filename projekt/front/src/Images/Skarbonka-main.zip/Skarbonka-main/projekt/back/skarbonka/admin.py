from django.contrib import admin
from .models import Skarbonka
# Register your models here.
admin.site.register(Skarbonka)
